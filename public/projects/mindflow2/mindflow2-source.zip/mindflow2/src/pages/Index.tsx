import { CBTApp } from '@/components/cbt/CBTApp';

const Index = () => {
  return <CBTApp />;
};

export default Index;
